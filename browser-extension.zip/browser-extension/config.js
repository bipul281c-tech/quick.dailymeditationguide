const SUPABASE_URL = 'https://oilicrcgqihpcajjjwfp.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9pbGljcmNncWlocGNhampqd2ZwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ3MDM0NDUsImV4cCI6MjA4MDI3OTQ0NX0.pk5NbDPfY_nf334a8Cu7nVrok9fPl2H0J3gxJbUOTSc';
const SITE_URL = 'https://www.quick.dailymeditationguide.com';
const PROJECT_REF = 'oilicrcgqihpcajjjwfp';
